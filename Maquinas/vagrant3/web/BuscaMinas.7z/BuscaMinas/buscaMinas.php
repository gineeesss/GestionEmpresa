<?php
define('FILAS', 5);
define('COLUMNAS', 6);
define('MINAS', 5);

session_start();
if (!isset($_SESSION['tablero'])) {
    $tablero = array_fill(0, FILAS, array_fill(0, COLUMNAS, 0));
    $minasColocadas = 0;
    while ($minasColocadas < MINAS) {
        $fila = rand(0, FILAS - 1);
        $columna = rand(0, COLUMNAS - 1);
        if ($tablero[$fila][$columna] !== 'M') {
            $tablero[$fila][$columna] = 'M';
            $minasColocadas++;
        }
    }

    for ($i = 0; $i < FILAS; $i++) {
        for ($j = 0; $j < COLUMNAS; $j++) {
            if ($tablero[$i][$j] === 'M') {
                continue;
            }
            $minasAlrededor = 0;
            for ($x = -1; $x <= 1; $x++) {
                for ($y = -1; $y <= 1; $y++) {
                    $nx = $i + $x;
                    $ny = $j + $y;
                    if ($nx >= 0 && $nx < FILAS && $ny >= 0 && $ny < COLUMNAS && $tablero[$nx][$ny] === 'M') {
                        $minasAlrededor++;
                    }
                }
            }
            $tablero[$i][$j] = $minasAlrededor;
        }
    }

    $_SESSION['tablero'] = $tablero;
    $_SESSION['revelados'] = array_fill(0, FILAS, array_fill(0, COLUMNAS, false));
} else {
    $tablero = $_SESSION['tablero'];
}

if (isset($_POST['fila']) && isset($_POST['columna'])) {
    $fila = $_POST['fila'];
    $columna = $_POST['columna'];
    $_SESSION['revelados'][$fila][$columna] = true;

    if ($tablero[$fila][$columna] === 'M') {
        echo "<script>alert('¡Has perdido!');</script>";
        session_destroy();
    }
}

function mostrarTablero($tablero) {
    $revelados = $_SESSION['revelados'];
    echo "<table border='1' cellspacing='0' cellpadding='5' style='border-collapse: collapse;'>";
    for ($i = 0; $i < FILAS; $i++) {
        echo "<tr>";
        for ($j = 0; $j < COLUMNAS; $j++) {
            echo "<td style='width: 30px; height: 30px; text-align: center; vertical-align: middle;'>";
            if ($revelados[$i][$j]) {
                if ($tablero[$i][$j] === 'M') {
                    echo "<div style='color:red;'>M</div>";
                } elseif ($tablero[$i][$j] > 0) {
                    echo "<div style='color:black;'>{$tablero[$i][$j]}</div>";
                } else {
                    echo "<div style='background-color: white; height: 30px; width: 30px;'></div>";
                }
            } else {
                echo "<form method='post' action='' style='margin: 0;'>";
                echo "<input type='hidden' name='fila' value='$i'>";
                echo "<input type='hidden' name='columna' value='$j'>";
                echo "<input type='submit' value=' ' style='width: 30px; height: 30px; background: lightblue; border: none; cursor: pointer;'>";
                echo "</form>";
            }
            echo "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}

mostrarTablero($tablero);
?>
